<?php

interface Dao {

	public function conectar();
	public function desconectar();
	public function ejecutarSQL($sql);
        public function ejecutarSentenciaPreparada($sql);
	public function leerUnaFila($objResultado);
	public function numeroFilas($objResultado);

}


?>