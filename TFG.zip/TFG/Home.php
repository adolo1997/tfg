<?php
session_start();
require_once 'conexion.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilo.css">

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <title>GESTOR DE DATOS</title>
    </head>
    <body>
        <!-- INICIO NABVAR -->
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-dark bg-dark">

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="navbar-toggler-icon"></span>
                </button> <a class="navbar-brand" href="#">
                    <?php
                    if (isset($_SESSION["usuario"])) {
                        echo "Bienvenido usuario: " . $_SESSION["usuario"];
                    } else {
                        echo 'Inicia sesion';
                    }
                    ?>
                </a>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="navbar-nav">
                        <li class="nav-item active">
                            <?php
                            if (isset($_SESSION["usuario"])) {
                                echo' <a class="nav-link" href="perfil.php?id=' . $_SESSION['usuario'] . '">Perfil <span class="sr-only">(current)</span></a>';
                            } else {
                                echo '<a class="nav-link" > Perfil <span class="sr-only">(current)</span></a>';
                            }
                            ?>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="getData.php">verJson</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown">Dropdown link</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="#">Action</a> <a class="dropdown-item" href="#">Another action</a> <a class="dropdown-item" href="#">Something else here</a>
                                <div class="dropdown-divider">
                                </div> <a class="dropdown-item" href="#">Separated link</a>
                            </div>
                        </li>
                    </ul>
                    <form class="form-inline">
                        <input class="form-control mr-sm-2" type="text" /> 
                        <button class="btn btn-primary my-2 my-sm-0" type="submit">
                            Search
                        </button>
                    </form>
                    <ul class="navbar-nav ml-md-auto">
                        <li class="nav-item">

                        </li>
                        <li class="nav-item" data-toggle="modal" data-target="#myModa2">
                            <a class="nav-link">Registrarse <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item" data-toggle="modal" data-target="#myModal">
                            <a class="nav-link">LogIn <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">LogOut</a>
                        </li>
                        <!-- INICIO MODAL LOGIN -->
                        <div class="modal fade" id="myModal" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Login</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post" action="acceder-login.php">
                                            <div class="form-group">
                                                <label for="user">Usuario o email</label>
                                                <input type="text" name="user" id="user" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label for="pass">Password</label>
                                                <input type="password" name="pass" id="pass" class="form-control">
                                            </div>
                                            <br><br>
                                            <div class="form-group">
                                                <input type="submit" name="login" id="login" value="Login" class="btn btn-success">
                                            </div>
                                            <br>
                                            <span id="result"></span>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- FINAL MODAL LOGIN -->
                        <!-- INICIO MODAL REGISTRO -->
                        <div class="modal fade" id="myModa2" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Registrarse</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post" action="crear-registros.php">
                                            <div class="form-group">
                                                Usuario <input type="text" class="form-control" name="user" />
                                            </div>
                                            <div class="form-group">
                                                Password <input type="password" class="form-control" name="pass" />
                                            </div>
                                            <div class="form-group">
                                                Email <input type="text" class="form-control" name="email" />
                                            </div>

                                            <div class="form-group">
                                                <input type="submit" name="registro" id="login" value="Registrarse" class="btn btn-success">
                                            </div>   
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- FINAL MODAL REGISTRO -->
                    </ul>
                </div>
            </nav>

            <!-- FINAL NAVBAR -->

            <!-- INICIO BREADCRUMBS HOME -->

            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">
                        <a href="#">Inicio</a>
                    </li>
                </ol>
            </nav>

            <!-- FINAL BREADCRUMBS HOME -->



            <div class="container">
                <div class="jumbotron">
                    <div class="row">
                        <div class="col-4">
                            <div class="row">
                                <!--<div class="lista-ingresos">-->
                                <span class="lista-txt">Tus ingresos</span>
                                <span class="lista-number">120$ </span>
                                <!--</div>-->
                            </div>
                            <div class="row">
                                <!--<div class="lista-ingresos">-->
                                <span class="lista-txt float-left">Tus gastos</span>
                                <span class="lista-number float-right">120$ </span>
                                <!--</div>-->
                            </div>
                        </div>
                        <div class="col-8" style="margin: 0 auto;">
                            <div id="chart_container" style=" height: 300px;"></div>
                        </div>
                        <!--                        <div>
                                                    <div id="tablajson">
<?php // require_once './getData.php';  ?>
                                                    </div>
                                                </div>
                                                <div>
                                                     <div id="piechart"></div>
                                                </div>-->

                    </div>
                </div>
            </div>

        </div>
<!--        <script type="text/javascript">
            google.charts.load('current', {'packages': ['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {

                var data = google.visualization.arrayToDataTable([$rawdatsa]);

                var options = {
                    title: 'My Daily Activities'
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                chart.draw(data, options);
            }
        </script>-->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    </body>
</html>
