<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("location:login.php");
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Index</title>
    </head>
    <body>
        <?php

        ?>
        <div id="sesion">
        <h1 align="center">Bienvenido usuario: <?php echo $_SESSION["user"]; ?></h1>
        <p align="center"><a href="logout.php">Logout</a></p>
        </div>
    </body>
</html>
