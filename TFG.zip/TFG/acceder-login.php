<?php
session_start();
$_SESSION['usuario'] = "";
require_once("MysqlDao.class.php");
$objDAO=new MysqlDao();
$objDAO->conectar();
$sql="SELECT * FROM usuarios WHERE user='".$_POST["user"]."' AND pass='".$_POST["pass"]."'";

$objResultado=$objDAO->ejecutarSQL($sql);
if ($objDAO->numeroFilas($objResultado)==0)
   {
    die("Usuario no existe en la BBDD o usuario/contraseña incorrecto.");
   } else 
   {
   $_SESSION['usuario'] = $_POST["user"];
   header("Location:Home.php");
   }    
$objDAO->desconectar();
?>