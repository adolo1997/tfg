<?php
session_start();
require_once './conexion.php';
if (isset($_SESSION["usuario"])) {
    echo 'bienvenido usuario: '.$id = $_SESSION["usuario"]; //actualmente pasa el $_SESSION["usuario"]
} else {
    die("Tiene que pasar el ID del alumno");
}
$SQL = "SELECT * FROM usuarios WHERE user=" . $id . ";";
$SQL = mysql_query($SQL, $objetoMysql);
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <table>
            <?php
            while ($registro = mysqly_fetch_array($SQL)) {
                echo '<tr>';
                echo '<td>' . $registro["id"] . '</td>';
                echo '<td>' . $registro["user"] . '</td>';
                echo '<td>' . $registro["email"] . '</td>';
                echo '<td>' . $registro["ingresos"] . '</td>';
                echo '<td>' . $registro["hipoteca"] . '</td>';
                echo '<td>' . $registro["gastos_generales"] . '</td>';
                echo '</tr>';
            }
            ?>
        </table>
    </body>
</html>
