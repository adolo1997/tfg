<?php
Global $objetoMysql;
 function connectDB() {
    
    define("SERVIDOR", "localhost");
    define("USER", "root");
    define("PASS", "");
    define("BBDD", "tfg");

    $objetoMysql = new Mysqli(SERVIDOR, USER, PASS, BBDD);

    if ($objetoMysql->connect_errno != 0) {
        die("Numeror de error: " . $objetoMysql->connect_errno .
                " descripcion:" . $objetoMysql->connect_error);
    }
    return $objetoMysql;
}


function disconnectDB($conexion) {

    $close = mysqli_close($conexion);

    return $close;
}

?>