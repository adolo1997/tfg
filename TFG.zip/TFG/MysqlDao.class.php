<?php
require_once 'Dao.iface.php';

class MysqlDao implements Dao {

        private $servidor="localhost";
        private $usuario="root";
        private $password="";
        private $basedatos="tfg";
        private $objMysqlI;
    
	public function conectar() {
            $this->objMysqlI=new mysqli($this->servidor, $this->usuario,$this->password,$this->basedatos);
            $this->objMysqlI->query("SET NAMES 'UTF8'");
	}


	public function desconectar() {
            $this->objMysqlI->close();
		
	}


	public function ejecutarSQL($sql) {

            return $this->objMysqlI->query($sql);
	}


	public function leerUnaFila($objResultado) {

		return $objResultado->fetch_array(); 
	}


	public function numeroFilas($objResultado) {

		return $objResultado->num_rows;
	}

        public function ejecutarSentenciaPreparada($sql) {
                
            return $this->objMysqlI->prepare($sql);
        }

}


?>