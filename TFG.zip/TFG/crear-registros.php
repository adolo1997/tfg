<?php
session_start();
require_once './conexion.php';
// Primero, transformamos los datos recibidos en entidades html para evitar inyecciones sql
$r_user = htmlentities($_POST['user'], ENT_QUOTES);
$r_pass = htmlentities($_POST['pass'], ENT_QUOTES);
$r_mail = htmlentities($_POST['email'], ENT_QUOTES);


$sql = "INSERT INTO usuarios (id,user, pass, email) VALUES('NULL','$r_user','$r_pass','$r_mail')";
if(mysqli_query($objetoMysql, $sql)){
        header("location:home.php");
}else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($objetoMysql);
}
    
?>